package Models;

public enum OrderState {
    CANCELLED, PAYED, PENDING, SHIPPED, COMPLETED
}