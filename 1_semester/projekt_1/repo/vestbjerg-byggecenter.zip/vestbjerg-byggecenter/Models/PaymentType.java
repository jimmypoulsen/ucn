package Models;

public enum PaymentType {
    CASH, CREDITCARD, INVOICE
}